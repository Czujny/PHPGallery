<?php

$routing = [
    '/' => 'index',
    '/wyslij' => 'wyslij',
    '/szukaj' => 'szukaj',
    '/licencje' => 'licencje',
    '/login' => 'login',
    '/rejestracja' => 'rejestracja',
    '/plik' => 'plik',
    '/panel' => 'panel',
    '/logout' => 'logout',
    '/zdjecie' => 'zdjecie',
    '/AJAXSearch' => 'AJAXSearch'
];